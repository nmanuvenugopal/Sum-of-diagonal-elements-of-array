import numpy as np

twoD_array = np.array([[1,2,3],[4,5,6],[7,8,9]])
print(twoD_array)

def diagonal_sum(my_array):
    sum = 0
    for i in range(len(my_array)):
        sum += my_array[i][i]

    print(f"Sum of the diagonal is {sum}")

diagonal_sum(twoD_array)
